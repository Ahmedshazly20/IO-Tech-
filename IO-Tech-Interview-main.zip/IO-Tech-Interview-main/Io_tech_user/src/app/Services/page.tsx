
import LegalServices from "@/components/layout/LegalServices";

export default function Legal() {
  return (
       <div >
        <LegalServices/>
      </div>
  );
}
