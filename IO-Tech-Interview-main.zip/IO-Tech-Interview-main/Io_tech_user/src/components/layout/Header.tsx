﻿export default function Header() {
    return <header className="p-4 border-b">Header</header>;
}
